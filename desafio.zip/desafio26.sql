DELETE FROM northwind.order_details
WHERE unit_price > 10.000;