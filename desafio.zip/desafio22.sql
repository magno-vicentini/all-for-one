UPDATE northwind.order_details
SET discount = 15;