SELECT product_name, id FROM northwind.products 
ORDER BY product_name;